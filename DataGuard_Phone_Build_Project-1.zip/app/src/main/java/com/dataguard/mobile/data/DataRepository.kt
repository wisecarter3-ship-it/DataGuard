package com.dataguard.mobile.data

import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.net.ConnectivityManager
import android.os.Process
import com.dataguard.mobile.model.AppUsage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.util.Calendar

class DataRepository(private val context: Context, private val db: AppDatabase) {
    private val nsm = context.getSystemService(NetworkStatsManager::class.java)

    private fun monthStart(): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.DAY_OF_MONTH, 1)
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    suspend fun loadUsage(): List<AppUsage> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val limits = db.limits().observeAll().first().associateBy { it.packageName }
        val aggregate = nsm.querySummary(
            ConnectivityManager.TYPE_MOBILE,
            null,
            monthStart(),
            System.currentTimeMillis()
        )
        val wifi = nsm.querySummary(
            ConnectivityManager.TYPE_WIFI,
            null,
            monthStart(),
            System.currentTimeMillis()
        )
        val mobileMap = mutableMapOf<Int, Long>()
        val wifiMap = mutableMapOf<Int, Long>()
        fun read(stats: NetworkStats, map: MutableMap<Int, Long>) {
            val bucket = NetworkStats.Bucket()
            while (stats.hasNextBucket()) {
                stats.getNextBucket(bucket)
                map[bucket.uid] = (map[bucket.uid] ?: 0L) +
                    bucket.rxBytes + bucket.txBytes
            }
            stats.close()
        }
        read(aggregate, mobileMap)
        read(wifi, wifiMap)

        pm.getInstalledApplications(0).mapNotNull { info ->
            val uid = info.uid
            val mobile = mobileMap[uid] ?: 0L
            if (mobile == 0L) return@mapNotNull null
            val label = info.loadLabel(pm).toString()
            val lim = limits[info.packageName]
            AppUsage(info.packageName, label, uid, mobile, wifiMap[uid] ?: 0L,
                info.loadIcon(pm), lim?.limitBytes, lim?.warningPercent ?: 80,
                lim?.blocked ?: false)
        }.sortedByDescending { it.mobileBytes }
    }
}
