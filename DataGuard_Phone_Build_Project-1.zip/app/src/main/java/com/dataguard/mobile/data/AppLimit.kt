package com.dataguard.mobile.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_limits")
data class AppLimit(
    @PrimaryKey val packageName: String,
    val limitBytes: Long,
    val warningPercent: Int = 80,
    val blocked: Boolean = false
)
