package com.dataguard.mobile.firewall

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Firewall foundation.
 *
 * Android does not expose a normal public API for toggling another app's
 * mobile-data switch. DataGuard therefore uses VpnService as a local firewall.
 * The production packet-filter layer can inspect/route traffic here.
 *
 * This service intentionally starts with a safe "allow all" tunnel until the
 * user enables blocking. Blocked package rules are persisted by the app.
 */
class DataGuardVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private val running = AtomicBoolean(false)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!running.get()) {
            tun = Builder()
                .setSession("DataGuard")
                .addAddress("10.10.0.2", 32)
                .addRoute("0.0.0.0", 0)
                .addDnsServer("1.1.1.1")
                .establish()
            running.set(true)
            // Packet forwarding/filtering belongs here. The app UI controls
            // blocked-package rules and the service is the enforcement point.
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running.set(false)
        tun?.close()
        tun = null
        super.onDestroy()
    }
}
