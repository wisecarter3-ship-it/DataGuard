# Build DataGuard using only your Android phone

The project includes a GitHub Actions workflow that builds the APK in the cloud.

## Phone-only route

1. Create/sign in to a GitHub account in Chrome.
2. Create a new repository, for example `DataGuard`.
3. Upload the project files from this ZIP into the repository.
4. Make sure `.github/workflows/build-apk.yml` is present.
5. Open the repository's **Actions** tab.
6. Select **Build DataGuard APK**.
7. Tap **Run workflow**.
8. Wait for the build to finish.
9. Open the completed workflow run.
10. Download the **DataGuard-debug-apk** artifact.
11. Extract the artifact ZIP and install `app-debug.apk` on your phone.

## Android installation

Android may ask you to allow Chrome/files to install unknown apps. Only enable this for the app you are using to install your own APK, then disable it again afterward.

## Important

The APK is a debug/test build. It is suitable for testing the UI and Android permissions. Full packet-level VPN filtering still needs to be completed before claiming guaranteed per-app blocking.
