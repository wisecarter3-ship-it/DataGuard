# DataGuard

Modern Android mobile-data monitoring and control application.

## Features
- Mobile-data usage ranking by app
- Monthly usage aggregation
- Searchable app list
- Persistent per-app limits database
- Warning thresholds
- Firewall foundation using Android VpnService
- Modern Jetpack Compose UI
- Usage-access and notification settings shortcuts

## Build
Open the project in Android Studio (Ladybug or newer), let Gradle sync, then Run.

## Important Android behavior
`NetworkStatsManager` requires the user to grant Usage Access in Android Settings.

Android does not expose a normal third-party API to flip another app's system
"mobile data" toggle. DataGuard therefore uses a local `VpnService` firewall
architecture for enforcement. The supplied service establishes the tunnel and
is the enforcement point for package rules. A production release should add
a native packet-forwarding/filtering engine (or an audited VPN firewall
implementation) before advertising guaranteed packet-level blocking.

## Suggested next production work
1. Add packet forwarding/filtering engine.
2. Persist blocked package UID rules and apply them to VPN traffic.
3. Add monthly allowance persistence and notification worker.
4. Add daily/weekly charts and export.
5. Test OEM-specific Android restrictions (Samsung, Xiaomi, Huawei, etc.).
