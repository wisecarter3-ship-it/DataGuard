package com.dataguard.mobile.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [AppLimit::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun limits(): AppLimitDao
}
