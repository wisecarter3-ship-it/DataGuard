package com.dataguard.mobile

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.room.Room
import com.dataguard.mobile.data.AppDatabase
import com.dataguard.mobile.data.AppLimit
import com.dataguard.mobile.data.DataRepository
import com.dataguard.mobile.model.AppUsage
import com.dataguard.mobile.firewall.DataGuardVpnService
import kotlinx.coroutines.launch
import java.util.Locale

private val Green = Color(0xFF0B6B4B)
private val Dark = Color(0xFF10231D)
private val Bg = Color(0xFFF5F7F6)

class MainActivity : ComponentActivity() {
    private lateinit var db: AppDatabase
    private lateinit var repo: DataRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = Room.databaseBuilder(applicationContext, AppDatabase::class.java, "dataguard.db").build()
        repo = DataRepository(this, db)
        setContent { DataGuardApp(this, repo, db) }
    }

    fun usageAccessGranted(): Boolean {
        val ops = getSystemService(AppOpsManager::class.java)
        return ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(), packageName
        ) == AppOpsManager.MODE_ALLOWED
    }
}

@Composable
fun DataGuardApp(activity: MainActivity, repo: DataRepository, db: AppDatabase) {
    var tab by remember { mutableIntStateOf(0) }
    var usage by remember { mutableStateOf<List<AppUsage>>(emptyList()) }
    var search by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    fun refresh() { scope.launch { usage = repo.loadUsage() } }
    LaunchedEffect(Unit) { if (activity.usageAccessGranted()) refresh() }

    MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Bg)) {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(tab == 0, { tab = 0 }, icon = { Icon(Icons.Default.Dashboard, null) }, label = { Text("Overview") })
                    NavigationBarItem(tab == 1, { tab = 1 }, icon = { Icon(Icons.Default.Apps, null) }, label = { Text("Apps") })
                    NavigationBarItem(tab == 2, { tab = 2 }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
                }
            }
        ) { pad ->
            when (tab) {
                0 -> Overview(Modifier.padding(pad), usage, activity) { refresh() }
                1 -> AppsScreen(Modifier.padding(pad), usage, search, { search = it }, db, activity)
                else -> SettingsScreen(Modifier.padding(pad), activity)
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String? = null) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Dark)
        subtitle?.let { Text(it, color = Color.Gray) }
    }
}

fun fmt(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB","MB","GB","TB")
    var v = bytes.toDouble()
    var i = -1
    while (v >= 1024 && i < units.lastIndex) { v /= 1024; i++ }
    return String.format(Locale.US, "%.1f %s", v, units[i])
}

@Composable
fun Overview(modifier: Modifier, usage: List<AppUsage>, activity: MainActivity, refresh: () -> Unit) {
    val total = usage.sumOf { it.mobileBytes }
    Column(modifier.fillMaxSize().background(Bg)) {
        Header("DataGuard", "Your mobile-data control centre")
        Card(Modifier.padding(horizontal = 16.dp).fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(22.dp)) {
                Text("Mobile data used this month", color = Color.Gray)
                Text(fmt(total), style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold, color = Dark)
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { 0.74f },
                    modifier = Modifier.fillMaxWidth().height(9.dp),
                    color = Green
                )
                Spacer(Modifier.height(8.dp))
                Text("Set your monthly allowance in Settings", color = Color.Gray)
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Apps tracked", usage.size.toString(), Modifier.weight(1f))
            StatCard("Heavy users", usage.count { it.mobileBytes >= 1024L*1024*1024 }.toString(), Modifier.weight(1f))
        }
        Spacer(Modifier.height(18.dp))
        Text("Top data users", Modifier.padding(horizontal = 20.dp), fontWeight = FontWeight.Bold)
        LazyColumn(Modifier.padding(10.dp)) {
            items(usage.take(6)) { AppRow(it) }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Color.Gray)
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun AppRow(app: AppUsage) {
    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Android, null, tint = Green, modifier = Modifier.size(34.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(app.appName, fontWeight = FontWeight.SemiBold)
            Text(fmt(app.mobileBytes), color = Color.Gray)
            if (app.limitBytes != null)
                LinearProgressIndicator({ app.progress }, Modifier.fillMaxWidth().padding(top = 5.dp), color = if (app.progress >= .8f) Color(0xFFE38B24) else Green)
        }
        if (app.blocked) Icon(Icons.Default.Block, "Blocked", tint = Color.Red)
    }
}

@Composable
fun AppsScreen(
    modifier: Modifier, usage: List<AppUsage>, search: String, onSearch: (String)->Unit,
    db: AppDatabase, activity: MainActivity
) {
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf<AppUsage?>(null) }
    val filtered = usage.filter { it.appName.contains(search, true) || it.packageName.contains(search, true) }

    Column(modifier.fillMaxSize().background(Bg)) {
        Header("Apps", "Ranked by mobile-data consumption")
        OutlinedTextField(search, onSearch, Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            placeholder = { Text("Search apps") }, leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true, shape = RoundedCornerShape(16.dp))
        Spacer(Modifier.height(8.dp))
        LazyColumn {
            items(filtered) { app ->
                AppRow(app)
                HorizontalDivider(Modifier.padding(horizontal = 16.dp))
            }
        }
    }
}

@Composable
fun SettingsScreen(modifier: Modifier, activity: MainActivity) {
    Column(modifier.fillMaxSize().background(Bg)) {
        Header("Settings", "Configure DataGuard")
        SettingRow("Usage access", "Required to measure app data usage") {
            activity.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        SettingRow("Firewall", "Use DataGuard VPN to enforce app blocks") {
            val intent = VpnService.prepare(activity)
            if (intent != null) activity.startActivity(intent)
            else activity.startService(Intent(activity, DataGuardVpnService::class.java))
        }
        SettingRow("Notifications", "Receive warnings before limits are reached") {
            activity.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, activity.packageName)
            })
        }
    }
}

@Composable
fun SettingRow(title: String, subtitle: String, action: () -> Unit) {
    Card(Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth().clickable { action() },
        shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Settings, null, tint = Green)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Color.Gray)
            }
            Icon(Icons.Default.ChevronRight, null)
        }
    }
}
