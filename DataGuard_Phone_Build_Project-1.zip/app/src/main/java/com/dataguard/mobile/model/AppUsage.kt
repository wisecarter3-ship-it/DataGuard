package com.dataguard.mobile.model

data class AppUsage(
    val packageName: String,
    val appName: String,
    val uid: Int,
    val mobileBytes: Long,
    val wifiBytes: Long,
    val icon: android.graphics.drawable.Drawable? = null,
    val limitBytes: Long? = null,
    val warningPercent: Int = 80,
    val blocked: Boolean = false
) {
    val progress: Float get() =
        if (limitBytes == null || limitBytes == 0L) 0f
        else (mobileBytes.toFloat() / limitBytes).coerceIn(0f, 1f)
}
